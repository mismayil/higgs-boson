# Feature engineering ideas

- Feature processing: columns where there's a majority of (-999), transform them into 

- Feature = # of sensors that went overboard (-999)

- Feature extraction: run LASSO to automatically do feature extraction and then augment our features

- Stepwise regression can also do automatic feature extraction.

- Automatic feature selection a k-fold by testing which subset performs best.

